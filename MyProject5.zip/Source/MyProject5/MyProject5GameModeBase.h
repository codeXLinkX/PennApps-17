// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "MyProject5GameModeBase.generated.h"

/**
 * 
 */
UCLASS()
class MYPROJECT5_API AMyProject5GameModeBase : public AGameModeBase
{
	GENERATED_BODY()
	
	
	
	
};
